<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
require_once dirname(__DIR__) . '/app/anvil_import.php';
$tabs = ['dashboard'=>'Обзор','engineering'=>'Engineering OS','categories'=>'Категории','brands'=>'Бренды','products'=>'Товары','news'=>'Новости','pages'=>'Страницы','gallery'=>'Галерея','leads'=>'Заявки','settings'=>'Настройки','formulas'=>'Формулы','anvil_source'=>'Данные Anvil'];
$ventilationSettingFields = [
    'ventilation_people_airflow' => ['ventilation.people_airflow','Воздухообмен на человека, м³/ч',40,0,1000],
    'ventilation_supply_factor' => ['ventilation.supply_factor','Коэффициент притока',1,0,5],
    'ventilation_exhaust_factor' => ['ventilation.exhaust_factor','Коэффициент вытяжки',1,0,5],
    'ventilation_fan_reserve_percent' => ['ventilation.fan_reserve_percent','Резерв вентилятора, %',15,0,100],
    'ventilation_duct_velocity' => ['ventilation.duct_velocity','Скорость в воздуховоде, м/с',4,0.1,30],
    'ventilation_rounding_step' => ['ventilation.rounding_step','Шаг округления цены, ₽',10,1,100000],
    'ventilation_duct_rounding_step' => ['ventilation.duct_rounding_step','Шаг округления диаметра, мм',5,1,1000],
    'ventilation_price_equipment_base' => ['ventilation.price_equipment_base','Базовая стоимость установки, ₽',20000,0,100000000],
    'ventilation_price_automation' => ['ventilation.price_automation','Комплект автоматики, ₽',40000,0,100000000],
    'ventilation_price_ducts_m2' => ['ventilation.price_ducts_m2','Воздуховоды за метр, ₽',155,0,1000000],
    'ventilation_price_grille' => ['ventilation.price_grille','Решётка, ₽',480,0,10000000],
    'ventilation_price_diffuser' => ['ventilation.price_diffuser','Диффузор, ₽',650,0,10000000],
    'ventilation_price_fan' => ['ventilation.price_fan','Вентилятор, ₽',18000,0,100000000],
    'ventilation_price_recovery' => ['ventilation.price_recovery','Рекуператор, ₽',85000,0,100000000],
    'ventilation_price_filter' => ['ventilation.price_filter','Фильтр, ₽',6500,0,10000000],
    'ventilation_price_silencer' => ['ventilation.price_silencer','Шумоглушитель, ₽',8500,0,10000000],
    'ventilation_price_valve' => ['ventilation.price_valve','Клапан, ₽',3200,0,10000000],
    'ventilation_price_cooling' => ['ventilation.price_cooling','Охлаждающий блок, ₽',45000,0,100000000],
    'ventilation_cooling_capacity_per_unit' => ['ventilation.cooling_capacity_per_unit','Мощность одного охлаждающего блока, кВт',8,0.1,1000],
    'ventilation_heat_capacity' => ['ventilation.heat_capacity','Тепловой коэффициент',0.335,0,10],
    'ventilation_price_materials_percent' => ['ventilation.price_materials_percent','Материалы, %',15,0,300],
    'ventilation_installation_percent' => ['ventilation.installation_percent','Монтаж оборудования, %',50,0,300],
    'ventilation_duct_installation_percent' => ['ventilation.duct_installation_percent','Монтаж воздуховодов, %',80,0,300],
    'ventilation_commissioning_percent' => ['ventilation.commissioning_percent','Пусконаладка, %',10,0,300],
    'ventilation_additional_percent' => ['ventilation.additional_percent','Дополнительные расходы, %',3,0,300],
    'ventilation_recovery_default' => ['ventilation.recovery_default','Эффективность рекуперации, %',70,0,100],
];
$installationSettingFields = [
    'install_ac_standard' => ['installation.pricing.acStandard','Стандартный монтаж кондиционера, ₽',8500,0,10000000],
    'install_ac_premium' => ['installation.pricing.acPremium','Сложный монтаж кондиционера, ₽',12000,0,10000000],
    'install_ac_route' => ['installation.pricing.acAdditionalRoute','Дополнительная трасса кондиционера, ₽/м',1200,0,1000000],
    'install_vrf_route' => ['installation.pricing.vrfMainRoute','Магистраль VRV / VRF, ₽/м',2800,0,1000000],
    'install_vrf_branch' => ['installation.pricing.vrfBranch','Ответвление / рефнет VRV / VRF, ₽',4200,0,10000000],
    'install_outdoor_unit' => ['installation.pricing.outdoorUnit','Монтаж наружного блока, ₽',6500,0,10000000],
    'install_indoor_unit' => ['installation.pricing.indoorUnit','Монтаж внутреннего блока, ₽',3500,0,10000000],
    'install_commissioning' => ['installation.pricing.commissioning','Пусконаладка, ₽',6500,0,10000000],
    'install_pressure_test' => ['installation.pricing.pressureTest','Опрессовка азотом, ₽',3200,0,10000000],
    'install_vacuum' => ['installation.pricing.vacuum','Вакуумирование, ₽',1800,0,10000000],
    'install_refrigerant_charge' => ['installation.pricing.refrigerantCharge','Дозаправка хладагентом, ₽/кг',1200,0,1000000],
    'install_electrical' => ['installation.pricing.electricalConnection','Электрическое подключение, ₽',2800,0,10000000],
    'install_pump' => ['installation.pricing.condensatePumpInstall','Монтаж дренажной помпы, ₽',4500,0,10000000],
    'install_drilling' => ['installation.pricing.coreDrilling','Алмазное бурение / проходка, ₽',1800,0,10000000],
    'install_lift' => ['installation.pricing.liftHour','Подъёмник / автовышка за час, ₽',6500,0,10000000],
    'install_scaffold' => ['installation.pricing.scaffoldShift','Леса / высотные работы за смену, ₽',4200,0,10000000],
];
$tab = (string)($_GET['tab'] ?? 'dashboard');
if (!isset($tabs[$tab])) $tab = 'dashboard';
function slug_value(string $value): string {
    $map=['а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e','ж'=>'zh','з'=>'z','и'=>'i','й'=>'i','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'h','ц'=>'c','ч'=>'ch','ш'=>'sh','щ'=>'sch','ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya'];
    $ascii = function_exists('iconv') ? iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) : false;
    if ($ascii !== false) $value = strtolower($ascii);
    else $value = strtr(strtolower($value), $map);
    return trim(preg_replace('/[^a-z0-9]+/','-',$value) ?? '', '-') ?: 'page-'.bin2hex(random_bytes(3));
}
function engineering_project_health(array $project): array {
    $rooms = (int)($project['room_count'] ?? 0);
    $calculations = (int)($project['calculation_count'] ?? 0);
    $systems = (int)($project['system_count'] ?? 0);
    $equipment = (int)($project['equipment_count'] ?? 0);
    $estimates = (int)($project['estimate_count'] ?? 0);
    $score = 0;
    $score += trim((string)($project['title'] ?? '')) !== '' ? 10 : 0;
    $score += trim((string)($project['address'] ?? '')) !== '' ? 10 : 0;
    $score += trim((string)($project['client_name'] ?? '')) !== '' ? 5 : 0;
    $score += trim((string)($project['profile'] ?? '')) !== '' ? 5 : 0;
    $score += trim((string)($project['goal'] ?? '')) !== '' ? 5 : 0;
    $score += trim((string)($project['constraints_text'] ?? '')) !== '' ? 5 : 0;
    $score += $rooms > 0 ? 15 : 0;
    $score += $calculations > 0 ? 10 : 0;
    $score += $systems > 0 ? 10 : 0;
    $score += $equipment > 0 ? 5 : 0;
    $score += $estimates > 0 ? 10 : 0;
    $status = (string)($project['status'] ?? 'draft');
    $score += $status !== 'draft' ? 10 : 0;

    $risks = [];
    if (trim((string)($project['address'] ?? '')) === '') $risks[] = 'Не указан объект';
    if ($rooms === 0) $risks[] = 'Нет помещений';
    if ($calculations === 0) $risks[] = 'Нет расчётов';
    if ($systems === 0) $risks[] = 'Не выбрана система';
    if ($systems > 0 && $equipment === 0) $risks[] = 'Не назначено оборудование';
    if ($estimates === 0) $risks[] = 'Нет сметы';
    if ($status === 'draft') $risks[] = 'Черновик';

    if (trim((string)($project['address'] ?? '')) === '') {
        $stage = 'Объект'; $next = 'Указать адрес и исходные данные объекта';
    } elseif ($rooms === 0) {
        $stage = 'Помещения'; $next = 'Добавить помещения, площадь и количество людей';
    } elseif ($calculations === 0) {
        $stage = 'Расчёты'; $next = 'Зафиксировать результаты инженерных расчётов';
    } elseif ($systems === 0) {
        $stage = 'Системы'; $next = 'Добавить VRV / VRF, вентиляцию или кондиционирование';
    } elseif ($equipment === 0) {
        $stage = 'Оборудование'; $next = 'Назначить модели и производителя оборудования';
    } elseif ($estimates === 0) {
        $stage = 'Смета'; $next = 'Сформировать предварительную смету проекта';
    } elseif ($status === 'installation') {
        $stage = 'Монтаж'; $next = 'Зафиксировать завершение монтажа и пусконаладки';
    } elseif (in_array($status, ['service', 'completed'], true)) {
        $stage = 'Сервис'; $next = 'Проверить регламент и назначить обслуживание';
    } else {
        $stage = 'Монтаж'; $next = 'Согласовать сроки и перевести проект в монтаж';
    }
    return ['score'=>min(100,$score),'stage'=>$stage,'next_action'=>$next,'risks'=>$risks];
}
function validate_anvil_source_refs(PDO $pdo, mixed $value, array &$cache): void {
    if ($value instanceof stdClass) {
        if (($value->{'$type'} ?? null) === 'ref') {
            $table = $value->table ?? null;
            $id = $value->id ?? null;
            if (!is_string($table) || !in_array($table, KLIMA_ANVIL_EXPORT_TABLES, true) || !is_string($id) || $id === '') {
                throw new UserInputException('Ссылка в JSON имеет неверный формат.');
            }
            $key = $table . ':' . $id;
            if (!array_key_exists($key, $cache)) {
                static $queries = [];
                if (!isset($queries[$table])) {
                    $queries[$table] = $pdo->prepare('SELECT 1 FROM anvil_export_rows WHERE source_table=? AND source_id=? LIMIT 1');
                }
                $queries[$table]->execute([$table, $id]);
                $cache[$key] = (bool)$queries[$table]->fetchColumn();
            }
            if (!$cache[$key]) {
                throw new UserInputException('Ссылка ведёт на отсутствующую запись «' . $table . ' / ' . $id . '».');
            }
            return;
        }
        foreach (get_object_vars($value) as $key => $item) {
            if (preg_match('~(?:api[_-]?key|secret|password|token|remembered_logins)~i', (string)$key)) {
                throw new UserInputException('Пароли и ключи доступа запрещено сохранять в переносимом зеркале.');
            }
            validate_anvil_source_refs($pdo, $item, $cache);
        }
    } elseif (is_array($value)) {
        foreach ($value as $item) {
            validate_anvil_source_refs($pdo, $item, $cache);
        }
    }
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $action=(string)($_POST['action']??'');
    if ($action==='login') {
        $attempt=$_SESSION['login_attempt']??['n'=>0,'time'=>time()];
        if (time()-(int)$attempt['time']>900) $attempt=['n'=>0,'time'=>time()];
        $q=db()->prepare('SELECT id,login,password_hash FROM admins WHERE login=? LIMIT 1'); $q->execute([trim((string)($_POST['login']??''))]); $admin=$q->fetch();
        if ((int)$attempt['n']>=8 || !$admin || !password_verify((string)($_POST['password']??''),$admin['password_hash'])) {
            $attempt['n']=(int)$attempt['n']+1; $attempt['time']=time(); $_SESSION['login_attempt']=$attempt;
            flash('Неверный логин или пароль. Для новой локальной базы используйте admin / admin, затем измените пароль в настройках.','error'); redirect_to(site_path('admin/'));
        }
        session_regenerate_id(true); unset($_SESSION['login_attempt']); $_SESSION['admin_id']=(int)$admin['id']; redirect_to(site_path('admin/'));
    }
    if ($action==='logout') { unset($_SESSION['admin_id']); session_regenerate_id(true); redirect_to(site_path('admin/')); }
    if ($action==='change_credentials') {
        $current=admin_user();
        if (!$current) redirect_to(site_path('admin/'));
        $login=trim((string)($_POST['login']??'')); $old=(string)($_POST['current_password']??''); $new=(string)($_POST['new_password']??'');
        $q=db()->prepare('SELECT password_hash FROM admins WHERE id=?'); $q->execute([(int)$current['id']]); $hash=(string)$q->fetchColumn();
        if ($login==='' || strlen($login)>120 || !password_verify($old,$hash) || ($new!=='' && strlen($new)<10)) {
            flash('Проверьте логин, текущий пароль и длину нового пароля (не менее 10 символов).','error'); redirect_to(site_path('admin/?tab=settings'));
        }
        $q=db()->prepare('SELECT id FROM admins WHERE login=? AND id<>?'); $q->execute([$login,(int)$current['id']]);
        if ($q->fetchColumn()) { flash('Этот логин уже используется.','error'); redirect_to(site_path('admin/?tab=settings')); }
        if ($new==='') { $q=db()->prepare('UPDATE admins SET login=? WHERE id=?'); $q->execute([$login,(int)$current['id']]); }
        else { $q=db()->prepare('UPDATE admins SET login=?,password_hash=? WHERE id=?'); $q->execute([$login,password_hash($new,PASSWORD_DEFAULT),(int)$current['id']]); }
        flash('Данные администратора обновлены.'); redirect_to(site_path('admin/?tab=settings'));
    }
    $user=admin_user();
    if ($user) {
        ensure_anvil_export_schema(db());
    }
    if ($user && isset($_POST['save_anvil_export_row'])) {
        $sourceTable = (string)($_POST['source_table'] ?? '');
        $sourceId = (string)($_POST['source_id'] ?? '');
        $pageNumber = max(1, (int)($_POST['page'] ?? 1));
        try {
            if (!in_array($sourceTable, KLIMA_ANVIL_EXPORT_TABLES, true) || $sourceId === '') {
                throw new UserInputException('Не выбрана исходная запись Anvil.');
            }
            $raw = (string)($_POST['record_json'] ?? '');
            if ($raw === '' || strlen($raw) > 2 * 1024 * 1024) {
                throw new UserInputException('JSON записи пустой или превышает 2 МБ.');
            }
            try {
                $record = json_decode($raw, false, 512, JSON_THROW_ON_ERROR);
            } catch (JsonException $error) {
                throw new UserInputException('Проверьте JSON: ' . $error->getMessage());
            }
            if (!$record instanceof stdClass || !is_string($record->id ?? null) || $record->id !== $sourceId
                || !(($record->values ?? null) instanceof stdClass)
                || count(get_object_vars($record)) !== 2
            ) {
                throw new UserInputException('JSON должен содержать прежний id записи и объект values.');
            }
            $referenceCache = [];
            validate_anvil_source_refs(db(), $record->values, $referenceCache);
            $encoded = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            $update = db()->prepare('UPDATE anvil_export_rows SET record_json=?, imported_at=NOW() WHERE source_table=? AND source_id=?');
            $update->execute([$encoded, $sourceTable, $sourceId]);
            flash('Исходная запись обновлена. Сопоставленные разделы PHP-сайта обновляются отдельным импортом.');
        } catch (UserInputException $error) {
            flash($error->getMessage(), 'error');
        }
        redirect_to(site_path('admin/?tab=anvil_source&source_table=' . rawurlencode($sourceTable) . '&page=' . $pageNumber));
    }
    if ($user && $action === 'sync_anvil_mirror') {
        try {
            $synced = sync_anvil_export_mirror_to_site(db());
            flash('Зеркальные данные применены: категорий ' . $synced['categories']
                . ', брендов ' . $synced['brands'] . ', товаров ' . $synced['products']
                . ', проектов ' . $synced['projects'] . ', помещений ' . $synced['rooms']
                . ', систем ' . $synced['systems'] . ', расчётов ' . $synced['calculations']
                . ', смет ' . $synced['estimates'] . '.');
        } catch (RuntimeException $error) {
            flash($error->getMessage(), 'error');
        }
        redirect_to(site_path('admin/?tab=anvil_source'));
    }
    if ($user && in_array($action, ['save_project','save_project_room','save_project_system','save_project_calculation','save_project_estimate','delete_project','delete_project_room','delete_project_system','delete_project_calculation','delete_project_estimate'], true)) {
        try {
            if ($action === 'save_project') {
                $id = max(0, (int)($_POST['id'] ?? 0));
                $title = trim((string)($_POST['title'] ?? ''));
                $client = trim((string)($_POST['client_name'] ?? ''));
                $phone = trim((string)($_POST['phone'] ?? ''));
                $email = trim((string)($_POST['email'] ?? ''));
                $address = trim((string)($_POST['address'] ?? ''));
                $profile = trim((string)($_POST['profile'] ?? ''));
                $goal = trim((string)($_POST['goal'] ?? ''));
                $priority = (string)($_POST['priority'] ?? 'normal');
                $constraints = trim((string)($_POST['constraints_text'] ?? ''));
                $notes = trim((string)($_POST['notes'] ?? ''));
                $status = (string)($_POST['status'] ?? 'draft');
                $titleLength = function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title);
                $clientLength = function_exists('mb_strlen') ? mb_strlen($client, 'UTF-8') : strlen($client);
                $addressLength = function_exists('mb_strlen') ? mb_strlen($address, 'UTF-8') : strlen($address);
                if ($title === '' || $titleLength > 220) throw new UserInputException('Название проекта обязательно (до 220 символов).');
                if ($clientLength > 190 || $addressLength > 500) throw new UserInputException('Проверьте длину имени клиента или адреса объекта.');
                if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new UserInputException('Укажите корректный email или оставьте поле пустым.');
                if (!in_array($priority, ['low','normal','high','urgent'], true)) $priority = 'normal';
                if (!in_array($status, ['draft','active','installation','service','completed'], true)) $status = 'draft';
                $values = [$title,$client,$phone,$email,$address,$profile,$goal,$priority,$constraints,$notes,$status];
                if ($id > 0) {
                    $query = db()->prepare('UPDATE projects SET title=?,client_name=?,phone=?,email=?,address=?,profile=?,goal=?,priority=?,constraints_text=?,notes=?,status=?,updated_at=NOW() WHERE id=?');
                    $query->execute([...$values,$id]);
                    if ($query->rowCount() === 0) {
                        $exists = db()->prepare('SELECT id FROM projects WHERE id=?'); $exists->execute([$id]);
                        if (!$exists->fetchColumn()) throw new UserInputException('Проект не найден.');
                    }
                } else {
                    $query = db()->prepare('INSERT INTO projects (title,client_name,phone,email,address,profile,goal,priority,constraints_text,notes,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())');
                    $query->execute($values);
                }
                flash('Инженерный проект сохранён.');
                redirect_to(site_path('admin/?tab=engineering'));
            }

            if ($action === 'delete_project') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id < 1) throw new UserInputException('Не выбран проект.');
                $query = db()->prepare('DELETE FROM projects WHERE id=?');
                $query->execute([$id]);
                flash('Проект и его дочерние записи удалены.');
                redirect_to(site_path('admin/?tab=engineering'));
            }

            $projectId = (int)($_POST['project_id'] ?? 0);
            $projectCheck = db()->prepare('SELECT id FROM projects WHERE id=? LIMIT 1');
            $projectCheck->execute([$projectId]);
            if ($projectId < 1 || !$projectCheck->fetchColumn()) throw new UserInputException('Проект не найден. Обновите страницу и повторите действие.');

            if (in_array($action, ['delete_project_room','delete_project_system','delete_project_calculation','delete_project_estimate'], true)) {
                $deleteMap = [
                    'delete_project_room' => ['project_rooms','room_id'],
                    'delete_project_system' => ['project_systems','system_id'],
                    'delete_project_calculation' => ['project_calculations','calculation_id'],
                    'delete_project_estimate' => ['project_estimates','estimate_id'],
                ];
                [$tableName,$idField] = $deleteMap[$action];
                $recordId = (int)($_POST['record_id'] ?? 0);
                if ($recordId < 1) throw new UserInputException('Не выбрана запись для удаления.');
                $query = db()->prepare('DELETE FROM ' . $tableName . ' WHERE id=? AND project_id=?');
                $query->execute([$recordId,$projectId]);
                flash('Запись удалена из проекта.');
                redirect_to(site_path('admin/?tab=engineering'));
            }

            if ($action === 'save_project_room') {
                $name = trim((string)($_POST['name'] ?? ''));
                $purpose = trim((string)($_POST['purpose'] ?? ''));
                $areaRaw = str_replace(',', '.', trim((string)($_POST['area_m2'] ?? '0')));
                $heightRaw = str_replace(',', '.', trim((string)($_POST['height_m'] ?? '0')));
                $occupants = (int)($_POST['occupants'] ?? 0);
                if ($name === '') throw new UserInputException('Укажите название помещения.');
                if (!is_numeric($areaRaw) || (float)$areaRaw < 0 || (float)$areaRaw > 100000 || !is_numeric($heightRaw) || (float)$heightRaw < 0 || (float)$heightRaw > 100 || $occupants < 0 || $occupants > 100000) throw new UserInputException('Проверьте площадь, высоту и количество людей.');
                $recordId = (int)($_POST['room_id'] ?? 0);
                if ($recordId > 0) {
                    $query = db()->prepare('UPDATE project_rooms SET name=?,purpose=?,area_m2=?,height_m=?,occupants=?,notes=? WHERE id=? AND project_id=?');
                    $query->execute([$name,$purpose,(float)$areaRaw,(float)$heightRaw,$occupants,trim((string)($_POST['notes'] ?? '')),$recordId,$projectId]);
                } else {
                    $query = db()->prepare('INSERT INTO project_rooms (project_id,name,purpose,area_m2,height_m,occupants,notes,created_at) VALUES (?,?,?,?,?,?,?,NOW())');
                    $query->execute([$projectId,$name,$purpose,(float)$areaRaw,(float)$heightRaw,$occupants,trim((string)($_POST['notes'] ?? ''))]);
                }
                db()->prepare('UPDATE projects SET updated_at=NOW() WHERE id=?')->execute([$projectId]);
                flash('Помещение добавлено.');
            } elseif ($action === 'save_project_system') {
                $type = (string)($_POST['system_type'] ?? 'air_conditioning');
                $title = trim((string)($_POST['title'] ?? ''));
                $brand = trim((string)($_POST['brand'] ?? ''));
                $model = trim((string)($_POST['model'] ?? ''));
                $capacityRaw = str_replace(',', '.', trim((string)($_POST['capacity_kw'] ?? '0')));
                $quantity = max(1, min(10000, (int)($_POST['quantity'] ?? 1)));
                $systemStatus = (string)($_POST['system_status'] ?? 'planned');
                if ($title === '') throw new UserInputException('Укажите название инженерной системы.');
                if (!in_array($type, ['air_conditioning','multi_split','vrv_vrf','ventilation','refrigeration'], true)) $type = 'air_conditioning';
                if (!in_array($systemStatus, ['planned','selected','ordered','installed','service'], true)) $systemStatus = 'planned';
                if (!is_numeric($capacityRaw) || (float)$capacityRaw < 0 || (float)$capacityRaw > 100000) throw new UserInputException('Проверьте мощность системы.');
                $recordId = (int)($_POST['system_id'] ?? 0);
                if ($recordId > 0) {
                    $query = db()->prepare('UPDATE project_systems SET system_type=?,title=?,brand=?,model=?,capacity_kw=?,quantity=?,status=?,notes=? WHERE id=? AND project_id=?');
                    $query->execute([$type,$title,$brand,$model,(float)$capacityRaw,$quantity,$systemStatus,trim((string)($_POST['notes'] ?? '')),$recordId,$projectId]);
                } else {
                    $query = db()->prepare('INSERT INTO project_systems (project_id,system_type,title,brand,model,capacity_kw,quantity,status,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,NOW())');
                    $query->execute([$projectId,$type,$title,$brand,$model,(float)$capacityRaw,$quantity,$systemStatus,trim((string)($_POST['notes'] ?? ''))]);
                }
                db()->prepare('UPDATE projects SET updated_at=NOW() WHERE id=?')->execute([$projectId]);
                flash('Инженерная система добавлена.');
            } elseif ($action === 'save_project_calculation') {
                $title = trim((string)($_POST['title'] ?? ''));
                $type = (string)($_POST['system_type'] ?? 'air_conditioning');
                $status = (string)($_POST['calculation_status'] ?? 'draft');
                $inputRaw = trim((string)($_POST['input_json'] ?? '{}')) ?: '{}';
                $resultRaw = trim((string)($_POST['result_json'] ?? '{}')) ?: '{}';
                $inputs = json_decode($inputRaw, true);
                $results = json_decode($resultRaw, true);
                if ($title === '') throw new UserInputException('Укажите название расчёта.');
                if (!is_array($inputs) || !is_array($results)) throw new UserInputException('Входные данные и результат должны быть корректным JSON-объектом или массивом.');
                if (!in_array($type, ['air_conditioning','multi_split','vrv_vrf','ventilation','refrigeration'], true)) $type = 'air_conditioning';
                if (!in_array($status, ['draft','completed','needs_review'], true)) $status = 'draft';
                $inputJson = json_encode($inputs,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
                $resultJson = json_encode($results,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
                $recordId = (int)($_POST['calculation_id'] ?? 0);
                if ($recordId > 0) {
                    $query = db()->prepare('UPDATE project_calculations SET system_type=?,title=?,input_json=?,result_json=?,status=? WHERE id=? AND project_id=?');
                    $query->execute([$type,$title,$inputJson,$resultJson,$status,$recordId,$projectId]);
                } else {
                    $query = db()->prepare('INSERT INTO project_calculations (project_id,system_type,title,input_json,result_json,status,created_at) VALUES (?,?,?,?,?,?,NOW())');
                    $query->execute([$projectId,$type,$title,$inputJson,$resultJson,$status]);
                }
                db()->prepare('UPDATE projects SET updated_at=NOW() WHERE id=?')->execute([$projectId]);
                flash('Расчёт добавлен в инженерную историю проекта.');
            } elseif ($action === 'save_project_estimate') {
                $title = trim((string)($_POST['title'] ?? ''));
                $amountRaw = str_replace(',', '.', trim((string)($_POST['amount'] ?? '0')));
                $status = (string)($_POST['estimate_status'] ?? 'draft');
                if ($title === '') throw new UserInputException('Укажите название сметы.');
                if (!is_numeric($amountRaw) || (float)$amountRaw < 0 || (float)$amountRaw > 1000000000000) throw new UserInputException('Проверьте сумму сметы.');
                if (!in_array($status, ['draft','sent','approved','accepted'], true)) $status = 'draft';
                $recordId = (int)($_POST['estimate_id'] ?? 0);
                if ($recordId > 0) {
                    $query = db()->prepare('UPDATE project_estimates SET title=?,amount=?,status=?,notes=?,updated_at=NOW() WHERE id=? AND project_id=?');
                    $query->execute([$title,(float)$amountRaw,$status,trim((string)($_POST['notes'] ?? '')),$recordId,$projectId]);
                } else {
                    $query = db()->prepare('INSERT INTO project_estimates (project_id,title,amount,status,notes,created_at,updated_at) VALUES (?,?,?,?,?,NOW(),NOW())');
                    $query->execute([$projectId,$title,(float)$amountRaw,$status,trim((string)($_POST['notes'] ?? ''))]);
                }
                db()->prepare('UPDATE projects SET updated_at=NOW() WHERE id=?')->execute([$projectId]);
                flash('Смета добавлена.');
            }
            redirect_to(site_path('admin/?tab=engineering'));
        } catch (UserInputException $exception) {
            flash($exception->getMessage(), 'error');
            redirect_to(site_path('admin/?tab=engineering'));
        } catch (Throwable $exception) {
            error_log('Engineering OS action failed: ' . $exception->getMessage());
            flash('Не удалось сохранить данные инженерного проекта. Проверьте журнал PHP.', 'error');
            redirect_to(site_path('admin/?tab=engineering'));
        }
    }
    if ($user && isset($_POST['save_record'])) {
        try {
        $id=(int)($_POST['id']??0);
        if ($tab==='categories') {
            $title=trim((string)($_POST['title']??'')); if ($title==='') throw new UserInputException('Введите название категории.');
            $code=slug_value((string)($_POST['code']?:$title)); $parent=null;
            $check=db()->prepare('SELECT id FROM categories WHERE code=? AND id<>?'); $check->execute([$code,$id]); if ($check->fetchColumn()) throw new UserInputException('Категория с таким адресным кодом уже существует.');
            if (!empty($_POST['parent_code'])) { $q=db()->prepare('SELECT id FROM categories WHERE code=?'); $q->execute([$_POST['parent_code']]); $parent=$q->fetchColumn()?:null; }
            $image=image_upload()??trim((string)($_POST['image_url']??'')); $vals=[$code,$title,$parent,$image,(int)($_POST['sort_order']??100),isset($_POST['active'])?1:0];
            if ($id) { $q=db()->prepare('UPDATE categories SET code=?,title=?,parent_id=?,image_url=?,sort_order=?,active=? WHERE id=?'); $q->execute([...$vals,$id]); } else { $q=db()->prepare('INSERT INTO categories (code,title,parent_id,image_url,sort_order,active) VALUES (?,?,?,?,?,?)'); $q->execute($vals); }
        } elseif ($tab==='brands') {
            $name=trim((string)($_POST['name']??'')); if ($name==='') throw new UserInputException('Введите название бренда.');
            $check=db()->prepare('SELECT id FROM brands WHERE name=? AND id<>?'); $check->execute([$name,$id]); if ($check->fetchColumn()) throw new UserInputException('Такой бренд уже добавлен.');
            $vals=[$name,image_upload()??trim((string)($_POST['logo_url']??'')),trim((string)($_POST['description']??'')),isset($_POST['active'])?1:0];
            if ($id) { $q=db()->prepare('UPDATE brands SET name=?,logo_url=?,description=?,active=? WHERE id=?'); $q->execute([...$vals,$id]); } else { $q=db()->prepare('INSERT INTO brands (name,logo_url,description,active) VALUES (?,?,?,?)'); $q->execute($vals); }
        } elseif ($tab==='products') {
            $model=trim((string)($_POST['model']??'')); if ($model==='') throw new UserInputException('Укажите модель товара.');
            $raw=trim((string)($_POST['specifications']??'')); $specs=$raw===''?[]:json_decode($raw,true); if (!is_array($specs)) throw new UserInputException('Характеристики должны быть корректным JSON-массивом.');
            $sku=trim((string)($_POST['sku']??''));
            if ($sku!=='') { $check=db()->prepare('SELECT id FROM products WHERE sku=? AND id<>?'); $check->execute([$sku,$id]); if ($check->fetchColumn()) throw new UserInputException('Товар с таким артикулом уже существует.'); }
            $vals=[$model,$sku===''?null:$sku,($_POST['brand_id']??'')!==''?(int)$_POST['brand_id']:null,($_POST['category_id']??'')!==''?(int)$_POST['category_id']:null,trim((string)($_POST['description']??'')),max(0,(float)($_POST['price']??0)),image_upload()??trim((string)($_POST['image_url']??'')),json_encode($specs,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),isset($_POST['is_demo'])?1:0,isset($_POST['active'])?1:0];
            if ($id) { $q=db()->prepare('UPDATE products SET model=?,sku=?,brand_id=?,category_id=?,description=?,price=?,image_url=?,specifications=?,is_demo=?,active=? WHERE id=?'); $q->execute([...$vals,$id]); } else { $q=db()->prepare('INSERT INTO products (model,sku,brand_id,category_id,description,price,image_url,specifications,is_demo,active,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,NOW())'); $q->execute($vals); }
        } elseif (in_array($tab,['news','pages'],true)) {
            $title=trim((string)($_POST['title']??'')); if ($title==='') throw new UserInputException('Введите заголовок.');
            $slug=slug_value((string)($_POST['slug']?:$title)); $content=safe_html((string)($_POST['content']??'')); $published=isset($_POST['published'])?1:0;
            $tableName=$tab==='news'?'news':'pages'; $check=db()->prepare('SELECT id FROM '.$tableName.' WHERE slug=? AND id<>?'); $check->execute([$slug,$id]); if ($check->fetchColumn()) throw new UserInputException('Адрес страницы уже занят. Укажите другой slug.');
            if ($tab==='news') {
                $image=image_upload()??trim((string)($_POST['image_url']??'')); $excerpt=trim((string)($_POST['excerpt']??''));
                if ($id) { $q=db()->prepare('UPDATE news SET title=?,slug=?,excerpt=?,content=?,image_url=?,published=?,published_at=IF(?=1,COALESCE(published_at,NOW()),NULL) WHERE id=?'); $q->execute([$title,$slug,$excerpt,$content,$image,$published,$published,$id]); }
                else { $q=db()->prepare('INSERT INTO news (title,slug,excerpt,content,image_url,published,created_at,published_at) VALUES (?,?,?,?,?,?,NOW(),IF(?=1,NOW(),NULL))'); $q->execute([$title,$slug,$excerpt,$content,$image,$published,$published]); }
            } else {
                if ($id) { $q=db()->prepare('UPDATE pages SET title=?,slug=?,content=?,published=?,updated_at=NOW() WHERE id=?'); $q->execute([$title,$slug,$content,$published,$id]); }
                else { $q=db()->prepare('INSERT INTO pages (title,slug,content,published,updated_at) VALUES (?,?,?,?,NOW())'); $q->execute([$title,$slug,$content,$published]); }
            }
        } elseif ($tab==='gallery') {
            $title=trim((string)($_POST['title']??'')); $image=image_upload()??trim((string)($_POST['image_url']??'')); if ($title===''||$image==='') throw new UserInputException('Укажите название и изображение.');
            $vals=[$title,trim((string)($_POST['alt_text']??'')),$image,trim((string)($_POST['location']??'')),(int)($_POST['sort_order']??100),isset($_POST['published'])?1:0];
            if ($id) { $q=db()->prepare('UPDATE gallery SET title=?,alt_text=?,image_url=?,location=?,sort_order=?,published=? WHERE id=?'); $q->execute([...$vals,$id]); } else { $q=db()->prepare('INSERT INTO gallery (title,alt_text,image_url,location,sort_order,published) VALUES (?,?,?,?,?,?)'); $q->execute($vals); }
        } elseif ($tab==='settings') {
            $q=db()->prepare('INSERT INTO settings (setting_key,setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
            if (array_intersect(['site_title','site_tagline','phone','email','address'], array_keys($_POST))) {
                foreach (['site_title','site_tagline','phone','email','address'] as $key) {
                    if (array_key_exists($key, $_POST)) $q->execute([$key,trim((string)$_POST[$key])]);
                }
            }
            foreach ($ventilationSettingFields as $field => [$key, $label, $default, $minimum, $maximum]) {
                if (!array_key_exists($field, $_POST)) continue;
                $raw = trim((string)$_POST[$field]);
                $normalised = str_replace(',', '.', $raw);
                if ($normalised === '' || !is_numeric($normalised) || !is_finite((float)$normalised) || (float)$normalised < $minimum || (float)$normalised > $maximum) {
                    throw new UserInputException('Проверьте настройку «' . $label . '»: допустимо от ' . $minimum . ' до ' . $maximum . '.');
                }
                $q->execute([$key, $normalised]);
            }
            foreach ($installationSettingFields as $field => [$key, $label, $default, $minimum, $maximum]) {
                if (!array_key_exists($field, $_POST)) continue;
                $raw = trim((string)$_POST[$field]);
                $normalised = str_replace(',', '.', $raw);
                if ($normalised === '' || !is_numeric($normalised) || !is_finite((float)$normalised) || (float)$normalised < $minimum || (float)$normalised > $maximum) {
                    throw new UserInputException('Проверьте настройку «' . $label . '»: допустимо от ' . $minimum . ' до ' . $maximum . '.');
                }
                $q->execute([$key, $normalised]);
            }
        } elseif ($tab==='leads') {
            $status=(string)($_POST['status']??'new'); if (!in_array($status,['new','in_progress','done'],true)) $status='new';
            $q=db()->prepare('UPDATE leads SET status=? WHERE id=?'); $q->execute([$status,$id]);
        }
        flash('Изменения сохранены.'); redirect_to(site_path('admin/?tab='.$tab));
        } catch (UserInputException $exception) {
            flash($exception->getMessage(), 'error');
            $return = !empty($_GET['edit']) ? '&edit=' . (int)$_GET['edit'] : '&new=1';
            redirect_to(site_path('admin/?tab=' . rawurlencode($tab) . $return));
        }
    }
    if ($user && isset($_POST['delete_record'])) {
        $tables=['categories'=>'categories','brands'=>'brands','products'=>'products','news'=>'news','pages'=>'pages','gallery'=>'gallery'];
        if (isset($tables[$tab])) { $q=db()->prepare('DELETE FROM '.$tables[$tab].' WHERE id=?'); $q->execute([(int)$_POST['id']]); }
        flash('Запись удалена.'); redirect_to(site_path('admin/?tab='.$tab));
    }
}
$user=admin_user();
if (!$user) {
    $message=take_flash(); ?>
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Вход · <?= e(setting('site_title','ЭКО-КЛИМАТ')) ?></title><link rel="stylesheet" href="<?= e(site_path('assets/style.css')) ?>"></head><body class="admin-login-body"><main class="login-card"><a class="brand" href="<?= e(site_path()) ?>"><span class="brand-mark">ЭК</span><span><?= e(setting('site_title','ЭКО-КЛИМАТ')) ?><small>ПАНЕЛЬ УПРАВЛЕНИЯ</small></span></a><p class="eyebrow">УПРАВЛЕНИЕ САЙТОМ</p><h1>Вход в админ-панель</h1><?php if ($message): ?><div class="notice error"><?= e($message['message']) ?></div><?php endif; ?><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="login"><label>Логин<input name="login" autocomplete="username" required autofocus></label><label>Пароль<input type="password" name="password" autocomplete="current-password" required></label><button class="button login-submit">Войти ↗</button></form><a class="login-back" href="<?= e(site_path()) ?>">← На сайт</a></main></body></html><?php exit;
}
ensure_anvil_export_schema(db());
$sourceMirrorCount = (int)db()->query('SELECT COUNT(*) FROM anvil_export_rows')->fetchColumn();
$counts=[]; foreach (['categories','brands','products','news','pages','gallery','leads','formulas'] as $t) $counts[$t]=(int)db()->query('SELECT COUNT(*) FROM '.$t)->fetchColumn();
$counts['engineering']=(int)db()->query('SELECT COUNT(*) FROM projects')->fetchColumn();
$counts['anvil_source']=$sourceMirrorCount;
$flashMessage=take_flash(); $edit=null;
if (!empty($_GET['edit']) && in_array($tab,['categories','brands','products','news','pages','gallery'],true)) { $q=db()->prepare('SELECT * FROM '.$tab.' WHERE id=?'); $q->execute([(int)$_GET['edit']]); $edit=$q->fetch()?:null; }
function admin_delete_control(int $id): void {
    echo '<form class="inline-delete" method="post" onsubmit="return confirm(\'Удалить эту запись?\')"><input type="hidden" name="_csrf" value="' . e(csrf_token()) . '"><input type="hidden" name="delete_record" value="1"><input type="hidden" name="id" value="' . $id . '"><button>Удалить</button></form>';
}
?>
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= e($tabs[$tab]) ?> · Управление сайтом</title><link rel="stylesheet" href="<?= e(site_path('assets/style.css')) ?>"></head><body class="admin-body">
<header class="admin-topbar"><a class="brand" href="<?= e(site_path()) ?>"><span class="brand-mark">ЭК</span><span><?= e(setting('site_title','ЭКО-КЛИМАТ')) ?><small>УПРАВЛЕНИЕ САЙТОМ</small></span></a><div class="admin-top-actions"><a class="button button-small button-ghost" href="<?= e(site_path()) ?>" target="_blank">Открыть сайт ↗</a><span><?= e($user['login']) ?></span><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="logout"><button class="logout-button">Выйти</button></form></div></header>
<div class="admin-shell"><aside class="admin-sidebar"><div class="admin-sidebar-label">РАЗДЕЛЫ САЙТА</div><?php foreach ($tabs as $key=>$label): ?><a class="admin-nav <?= $tab===$key?'active':'' ?>" href="<?= e(site_path('admin/?tab='.$key)) ?>"><span><?= e($label) ?></span><?php if (isset($counts[$key])): ?><small><?= $counts[$key] ?></small><?php endif; ?></a><?php endforeach; ?><div class="admin-sidebar-bottom">PHP CMS · <?= date('Y') ?></div></aside><main class="admin-main">
<?php if ($flashMessage): ?><div class="notice <?= e($flashMessage['kind']) ?>"><?= e($flashMessage['message']) ?></div><?php endif; ?><div class="admin-page-heading"><div><p class="eyebrow">ПАНЕЛЬ УПРАВЛЕНИЯ / <?= e(strtoupper($tab)) ?></p><h1><?= e($tabs[$tab]) ?></h1></div><?php if (in_array($tab,['categories','brands','products','news','pages','gallery'],true)): ?><a class="button button-small" href="<?= e(site_path('admin/?tab='.$tab.'&new=1')) ?>">＋ Добавить</a><?php endif; ?></div>
<?php if ($tab==='dashboard'): ?><div class="stats-grid"><?php foreach (['engineering'=>'Инженерных проектов','categories'=>'Категорий','brands'=>'Брендов','products'=>'Товаров','news'=>'Публикаций','gallery'=>'Фотографий','leads'=>'Заявок'] as $key=>$label): ?><a class="stat-card" href="<?= e(site_path('admin/?tab='.$key)) ?>"><span><?= e($label) ?></span><strong><?= $counts[$key] ?></strong><i>Открыть ↗</i></a><?php endforeach; ?></div><section class="admin-panel welcome-panel"><p class="eyebrow">ВАШ САЙТ УСТАНОВЛЕН</p><h2>Добавьте своё оборудование и проекты</h2><p>Заполните контакты, замените тестовые карточки и загрузите фотографии работ. Демо-товары помечены и не предназначены для продажи.</p><div class="quick-links"><a href="<?= e(site_path('admin/?tab=settings')) ?>">Настройки сайта ↗</a><a href="<?= e(site_path('admin/?tab=products&new=1')) ?>">Добавить товар ↗</a><a href="<?= e(site_path('admin/?tab=gallery&new=1')) ?>">Добавить работу ↗</a></div></section>
<?php elseif ($tab==='engineering'):
$projects = db()->query("SELECT p.*,
    (SELECT COUNT(*) FROM project_rooms r WHERE r.project_id=p.id) AS room_count,
    (SELECT COUNT(*) FROM project_calculations c WHERE c.project_id=p.id) AS calculation_count,
    (SELECT COUNT(*) FROM project_systems s WHERE s.project_id=p.id) AS system_count,
    (SELECT COUNT(*) FROM project_systems s WHERE s.project_id=p.id AND TRIM(s.model)<>'') AS equipment_count,
    (SELECT COUNT(*) FROM project_estimates e WHERE e.project_id=p.id) AS estimate_count
    FROM projects p ORDER BY p.updated_at DESC, p.id DESC")->fetchAll();
$roomsByProject=[]; foreach (db()->query('SELECT * FROM project_rooms ORDER BY id DESC') as $row) $roomsByProject[(int)$row['project_id']][]=$row;
$systemsByProject=[]; foreach (db()->query('SELECT * FROM project_systems ORDER BY id DESC') as $row) $systemsByProject[(int)$row['project_id']][]=$row;
$calculationsByProject=[]; foreach (db()->query('SELECT * FROM project_calculations ORDER BY id DESC') as $row) $calculationsByProject[(int)$row['project_id']][]=$row;
$estimatesByProject=[]; foreach (db()->query('SELECT * FROM project_estimates ORDER BY id DESC') as $row) $estimatesByProject[(int)$row['project_id']][]=$row;
$activeProjects=count(array_filter($projects, static fn($p)=>!in_array($p['status'],['completed','service'],true)));
$attentionProjects=count(array_filter($projects, static fn($p)=>(int)$p['room_count']===0 || (int)$p['calculation_count']===0 || trim((string)$p['address'])===''));
?><section class="admin-panel engineering-control-room"><p class="eyebrow">ENGINEERING OS / CONTROL ROOM</p><h2>Жизненный цикл инженерного объекта</h2><p class="muted">Объект → помещения → расчёты → системы → оборудование → смета → монтаж → сервис. Проектный балл и следующий шаг рассчитываются из заполненности данных, а не вводятся вручную.</p><div class="stats-grid engineering-stats"><div class="stat-card"><span>Всего проектов</span><strong><?= count($projects) ?></strong></div><div class="stat-card"><span>Активные</span><strong><?= $activeProjects ?></strong></div><div class="stat-card"><span>Требуют внимания</span><strong><?= $attentionProjects ?></strong></div><div class="stat-card"><span>Инженерные системы</span><strong><?= array_sum(array_map(static fn($p)=>(int)$p['system_count'],$projects)) ?></strong></div></div></section>
<section class="admin-panel engineering-create"><div class="panel-heading"><div><p class="eyebrow">НОВЫЙ ОБЪЕКТ</p><h2>Создать инженерный проект</h2></div></div><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project"><div class="form-grid"><label class="span-2">Название проекта<input name="title" maxlength="220" required placeholder="Например, Офис — система климатизации"></label><label>Заказчик<input name="client_name" maxlength="190"></label><label>Телефон<input name="phone" maxlength="80"></label><label>Email<input name="email" type="email" maxlength="190"></label><label>Адрес объекта<input name="address" maxlength="500" placeholder="Город, адрес, корпус"></label><label>Профиль объекта<select name="profile"><option value="">Не выбран</option><option value="residential">Жилой объект</option><option value="office">Офис</option><option value="retail">Торговля</option><option value="industrial">Промышленный</option><option value="hospitality">Гостиница / ресторан</option><option value="other">Другое</option></select></label><label>Приоритет<select name="priority"><option value="normal">Обычный</option><option value="low">Низкий</option><option value="high">Высокий</option><option value="urgent">Срочный</option></select></label><label class="span-2">Цель проекта<textarea name="goal" rows="2" placeholder="Что требуется обеспечить на объекте"></textarea></label><label class="span-2">Ограничения и исходные условия<textarea name="constraints_text" rows="2" placeholder="Бюджет, сроки, архитектурные и технические ограничения"></textarea></label><label class="span-2">Заметки<textarea name="notes" rows="2"></textarea></label></div><button class="button">＋ Создать проект</button></form></section>
<?php if (!$projects): ?><section class="admin-panel empty-state"><h2>Проектов пока нет</h2><p>Создайте объект выше, затем добавьте помещения, расчёты, инженерные системы и смету. Данные сохраняются в локальной базе.</p></section><?php endif; ?>
<?php foreach ($projects as $project): $health=engineering_project_health($project); $projectId=(int)$project['id']; ?>
<section class="admin-panel engineering-project-card"><div class="engineering-project-heading"><div><p class="eyebrow">ОБЪЕКТ #<?= $projectId ?> · <?= e(strtoupper((string)$project['priority'])) ?> ПРИОРИТЕТ</p><h2><?= e($project['title']) ?></h2><p class="muted"><?= e($project['client_name'] ?: 'Заказчик не указан') ?> · <?= e($project['address'] ?: 'Адрес не заполнен') ?></p></div><div class="engineering-score"><strong><?= (int)$health['score'] ?><small>/100</small></strong><span>Engineering Score</span><div class="score-track"><i style="width:<?= (int)$health['score'] ?>%"></i></div></div></div>
<div class="engineering-metrics"><span><b><?= (int)$project['room_count'] ?></b> помещений</span><span><b><?= (int)$project['calculation_count'] ?></b> расчётов</span><span><b><?= (int)$project['system_count'] ?></b> систем</span><span><b><?= (int)$project['equipment_count'] ?></b> назначений оборудования</span><span><b><?= (int)$project['estimate_count'] ?></b> смет</span></div>
<div class="engineering-next-action"><span class="eyebrow">СЛЕДУЮЩИЙ ШАГ · <?= e($health['stage']) ?></span><strong><?= e($health['next_action']) ?></strong></div>
<?php if ($health['risks']): ?><div class="engineering-risks"><span class="muted">Риски:</span><?php foreach ($health['risks'] as $risk): ?><span class="risk-tag"><?= e($risk) ?></span><?php endforeach; ?></div><?php else: ?><p class="success-line">Критические пробелы по базовым данным не обнаружены.</p><?php endif; ?>
<details class="engineering-details"><summary>Редактировать объект и статус</summary><form method="post" class="engineering-edit-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project"><input type="hidden" name="id" value="<?= $projectId ?>"><div class="form-grid"><label class="span-2">Название<input name="title" maxlength="220" required value="<?= e($project['title']) ?>"></label><label>Заказчик<input name="client_name" maxlength="190" value="<?= e($project['client_name']) ?>"></label><label>Телефон<input name="phone" maxlength="80" value="<?= e($project['phone']) ?>"></label><label>Email<input name="email" type="email" maxlength="190" value="<?= e($project['email']) ?>"></label><label>Адрес объекта<input name="address" maxlength="500" value="<?= e($project['address']) ?>"></label><label>Профиль<select name="profile"><?php foreach ([''=>'Не выбран','residential'=>'Жилой объект','office'=>'Офис','retail'=>'Торговля','industrial'=>'Промышленный','hospitality'=>'Гостиница / ресторан','other'=>'Другое'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $project['profile']===$value?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label>Приоритет<select name="priority"><?php foreach (['low'=>'Низкий','normal'=>'Обычный','high'=>'Высокий','urgent'=>'Срочный'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $project['priority']===$value?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label>Стадия проекта<select name="status"><?php foreach (['draft'=>'Черновик','active'=>'Активный','installation'=>'Монтаж','service'=>'Сервис','completed'=>'Завершён'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $project['status']===$value?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label class="span-2">Цель<textarea name="goal" rows="2"><?= e($project['goal']) ?></textarea></label><label class="span-2">Ограничения<textarea name="constraints_text" rows="2"><?= e($project['constraints_text']) ?></textarea></label><label class="span-2">Заметки<textarea name="notes" rows="2"><?= e($project['notes']) ?></textarea></label></div><button class="button button-small">Сохранить проект</button></form></details>
<div class="engineering-workstreams"><details class="engineering-details"><summary>Помещения · <?= (int)$project['room_count'] ?></summary><?php foreach (($roomsByProject[$projectId]??[]) as $room): ?><div class="engineering-record"><strong><?= e($room['name']) ?></strong><span><?= e($room['purpose']) ?> · <?= number_format((float)$room['area_m2'],1,',',' ') ?> м² · высота <?= number_format((float)$room['height_m'],1,',',' ') ?> м · людей: <?= (int)$room['occupants'] ?></span><?php if ($room['notes']!==''): ?><small><?= e($room['notes']) ?></small><?php endif; ?><details class="engineering-record-tools"><summary>Изменить / удалить</summary><form method="post" class="engineering-inline-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project_room"><input type="hidden" name="project_id" value="<?= $projectId ?>"><input type="hidden" name="room_id" value="<?= (int)$room['id'] ?>"><div class="form-grid"><label>Название<input name="name" required maxlength="190" value="<?= e($room['name']) ?>"></label><label>Назначение<input name="purpose" maxlength="190" value="<?= e($room['purpose']) ?>"></label><label>Площадь, м²<input name="area_m2" type="number" min="0" max="100000" step="0.1" value="<?= e($room['area_m2']) ?>"></label><label>Высота, м<input name="height_m" type="number" min="0" max="100" step="0.1" value="<?= e($room['height_m']) ?>"></label><label>Людей<input name="occupants" type="number" min="0" max="100000" value="<?= (int)$room['occupants'] ?>"></label><label class="span-2">Примечание<input name="notes" maxlength="2000" value="<?= e($room['notes']) ?>"></label></div><button class="button button-small">Сохранить помещение</button></form><form method="post" class="engineering-delete-form" onsubmit="return confirm('Удалить помещение?')"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_project_room"><input type="hidden" name="project_id" value="<?= $projectId ?>"><input type="hidden" name="record_id" value="<?= (int)$room['id'] ?>"><button class="button button-danger button-small">Удалить помещение</button></form></details></div><?php endforeach; ?><form method="post" class="engineering-inline-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project_room"><input type="hidden" name="project_id" value="<?= $projectId ?>"><div class="form-grid"><label>Название помещения<input name="name" required maxlength="190" placeholder="Переговорная / зал"></label><label>Назначение<input name="purpose" maxlength="190"></label><label>Площадь, м²<input name="area_m2" type="number" min="0" max="100000" step="0.1" value="0"></label><label>Высота, м<input name="height_m" type="number" min="0" max="100" step="0.1" value="0"></label><label>Людей<input name="occupants" type="number" min="0" max="100000" value="0"></label><label class="span-2">Примечание<input name="notes" maxlength="2000"></label></div><button class="button button-small">＋ Добавить помещение</button></form></details>
<details class="engineering-details"><summary>Инженерные системы · <?= (int)$project['system_count'] ?></summary><?php foreach (($systemsByProject[$projectId]??[]) as $system): ?><div class="engineering-record"><strong><?= e($system['title']) ?></strong><span><?= e(['air_conditioning'=>'Кондиционирование','multi_split'=>'Мульти-сплит','vrv_vrf'=>'VRV / VRF','ventilation'=>'Вентиляция','refrigeration'=>'Холодоснабжение'][$system['system_type']]??$system['system_type']) ?> · <?= e($system['brand'] ?: 'бренд не назначен') ?> <?= e($system['model']) ?> · <?= number_format((float)$system['capacity_kw'],2,',',' ') ?> кВт × <?= (int)$system['quantity'] ?> · <?= e($system['status']) ?></span><?php if ($system['notes']!==''): ?><small><?= e($system['notes']) ?></small><?php endif; ?><details class="engineering-record-tools"><summary>Изменить / удалить</summary><form method="post" class="engineering-inline-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project_system"><input type="hidden" name="project_id" value="<?= $projectId ?>"><input type="hidden" name="system_id" value="<?= (int)$system['id'] ?>"><div class="form-grid"><label>Название<input name="title" required maxlength="220" value="<?= e($system['title']) ?>"></label><label>Тип<select name="system_type"><?php foreach (['air_conditioning'=>'Кондиционирование','multi_split'=>'Мульти-сплит','vrv_vrf'=>'VRV / VRF','ventilation'=>'Вентиляция','refrigeration'=>'Холодоснабжение'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $system['system_type']===$value?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label>Бренд<input name="brand" maxlength="190" value="<?= e($system['brand']) ?>"></label><label>Модель<input name="model" maxlength="190" value="<?= e($system['model']) ?>"></label><label>Мощность, кВт<input name="capacity_kw" type="number" min="0" max="100000" step="0.01" value="<?= e($system['capacity_kw']) ?>"></label><label>Количество<input name="quantity" type="number" min="1" max="10000" value="<?= (int)$system['quantity'] ?>"></label><label>Статус<select name="system_status"><?php foreach (['planned'=>'Планируется','selected'=>'Подобрано','ordered'=>'Заказано','installed'=>'Установлено','service'=>'Сервис'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $system['status']===$value?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label class="span-2">Примечание<input name="notes" maxlength="2000" value="<?= e($system['notes']) ?>"></label></div><button class="button button-small">Сохранить систему</button></form><form method="post" class="engineering-delete-form" onsubmit="return confirm('Удалить систему?')"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_project_system"><input type="hidden" name="project_id" value="<?= $projectId ?>"><input type="hidden" name="record_id" value="<?= (int)$system['id'] ?>"><button class="button button-danger button-small">Удалить систему</button></form></details></div><?php endforeach; ?><form method="post" class="engineering-inline-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project_system"><input type="hidden" name="project_id" value="<?= $projectId ?>"><div class="form-grid"><label>Тип системы<select name="system_type"><option value="air_conditioning">Кондиционирование</option><option value="multi_split">Мульти-сплит</option><option value="vrv_vrf">VRV / VRF</option><option value="ventilation">Вентиляция</option><option value="refrigeration">Холодоснабжение</option></select></label><label>Название системы<input name="title" required maxlength="220" placeholder="Приточно-вытяжная система №1"></label><label>Бренд<input name="brand" maxlength="190"></label><label>Модель<input name="model" maxlength="190"></label><label>Мощность, кВт<input name="capacity_kw" type="number" min="0" max="100000" step="0.01" value="0"></label><label>Количество<input name="quantity" type="number" min="1" max="10000" value="1"></label><label>Статус<select name="system_status"><option value="planned">Планируется</option><option value="selected">Подобрано</option><option value="ordered">Заказано</option><option value="installed">Установлено</option><option value="service">Сервис</option></select></label><label class="span-2">Примечание<input name="notes" maxlength="2000"></label></div><button class="button button-small">＋ Добавить систему</button></form></details>
<details class="engineering-details"><summary>Расчёты · <?= (int)$project['calculation_count'] ?></summary><?php foreach (($calculationsByProject[$projectId]??[]) as $calc): ?><div class="engineering-record"><strong><?= e($calc['title']) ?></strong><span><?= e($calc['system_type']) ?> · <?= e($calc['status']) ?> · <?= e($calc['created_at']) ?></span><details class="engineering-record-tools"><summary>Изменить / удалить</summary><form method="post" class="engineering-inline-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project_calculation"><input type="hidden" name="project_id" value="<?= $projectId ?>"><input type="hidden" name="calculation_id" value="<?= (int)$calc['id'] ?>"><div class="form-grid"><label>Название<input name="title" required maxlength="220" value="<?= e($calc['title']) ?>"></label><label>Система<select name="system_type"><?php foreach (['air_conditioning'=>'Кондиционирование','multi_split'=>'Мульти-сплит','vrv_vrf'=>'VRV / VRF','ventilation'=>'Вентиляция','refrigeration'=>'Холодоснабжение'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $calc['system_type']===$value?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label>Статус<select name="calculation_status"><?php foreach (['draft'=>'Черновик','completed'=>'Завершён','needs_review'=>'Нужна проверка'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $calc['status']===$value?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label class="span-2">Входные JSON<textarea name="input_json" rows="2"><?= e($calc['input_json']) ?></textarea></label><label class="span-2">Результат JSON<textarea name="result_json" rows="2"><?= e($calc['result_json']) ?></textarea></label></div><button class="button button-small">Сохранить расчёт</button></form><form method="post" class="engineering-delete-form" onsubmit="return confirm('Удалить запись расчёта?')"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_project_calculation"><input type="hidden" name="project_id" value="<?= $projectId ?>"><input type="hidden" name="record_id" value="<?= (int)$calc['id'] ?>"><button class="button button-danger button-small">Удалить расчёт</button></form></details></div><?php endforeach; ?><form method="post" class="engineering-inline-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project_calculation"><input type="hidden" name="project_id" value="<?= $projectId ?>"><div class="form-grid"><label>Название расчёта<input name="title" required maxlength="220" placeholder="Расчёт воздухообмена"></label><label>Система<select name="system_type"><option value="air_conditioning">Кондиционирование</option><option value="multi_split">Мульти-сплит</option><option value="vrv_vrf">VRV / VRF</option><option value="ventilation">Вентиляция</option><option value="refrigeration">Холодоснабжение</option></select></label><label>Статус<select name="calculation_status"><option value="draft">Черновик</option><option value="completed">Завершён</option><option value="needs_review">Нужна проверка</option></select></label><label class="span-2">Входные данные JSON<textarea name="input_json" rows="2">{}</textarea></label><label class="span-2">Результат JSON<textarea name="result_json" rows="2">{}</textarea></label></div><button class="button button-small">＋ Записать расчёт</button><small class="muted">Сюда можно сохранить входные данные и результат существующего независимого калькулятора.</small></form></details>
<details class="engineering-details"><summary>Сметы · <?= (int)$project['estimate_count'] ?></summary><?php foreach (($estimatesByProject[$projectId]??[]) as $estimate): ?><div class="engineering-record"><strong><?= e($estimate['title']) ?></strong><span><?= number_format((float)$estimate['amount'],0,',',' ') ?> ₽ · <?= e($estimate['status']) ?> · <?= e($estimate['created_at']) ?></span><?php if ($estimate['notes']!==''): ?><small><?= e($estimate['notes']) ?></small><?php endif; ?><details class="engineering-record-tools"><summary>Изменить / удалить</summary><form method="post" class="engineering-inline-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project_estimate"><input type="hidden" name="project_id" value="<?= $projectId ?>"><input type="hidden" name="estimate_id" value="<?= (int)$estimate['id'] ?>"><div class="form-grid"><label>Название<input name="title" required maxlength="220" value="<?= e($estimate['title']) ?>"></label><label>Сумма, ₽<input name="amount" type="number" min="0" max="1000000000000" step="0.01" value="<?= e($estimate['amount']) ?>"></label><label>Статус<select name="estimate_status"><?php foreach (['draft'=>'Черновик','sent'=>'Отправлена','approved'=>'Согласована','accepted'=>'Принята'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $estimate['status']===$value?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label class="span-2">Примечание<input name="notes" maxlength="2000" value="<?= e($estimate['notes']) ?>"></label></div><button class="button button-small">Сохранить смету</button></form><form method="post" class="engineering-delete-form" onsubmit="return confirm('Удалить смету?')"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_project_estimate"><input type="hidden" name="project_id" value="<?= $projectId ?>"><input type="hidden" name="record_id" value="<?= (int)$estimate['id'] ?>"><button class="button button-danger button-small">Удалить смету</button></form></details></div><?php endforeach; ?><form method="post" class="engineering-inline-form"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_project_estimate"><input type="hidden" name="project_id" value="<?= $projectId ?>"><div class="form-grid"><label>Название сметы<input name="title" required maxlength="220" placeholder="Предварительная смета"></label><label>Сумма, ₽<input name="amount" type="number" min="0" max="1000000000000" step="0.01" value="0"></label><label>Статус<select name="estimate_status"><option value="draft">Черновик</option><option value="sent">Отправлена</option><option value="approved">Согласована</option><option value="accepted">Принята</option></select></label><label class="span-2">Примечание<input name="notes" maxlength="2000"></label></div><button class="button button-small">＋ Добавить смету</button></form></details></div>
<form method="post" class="engineering-delete-form" onsubmit="return confirm('Удалить проект и все связанные помещения, системы, расчёты и сметы?')"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_project"><input type="hidden" name="id" value="<?= $projectId ?>"><button class="button button-danger button-small">Удалить проект</button></form>
</section><?php endforeach; ?>
<?php elseif ($tab==='settings'): ?><section class="admin-panel"><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="save_record" value="1"><div class="form-grid"><label>Название сайта<input name="site_title" value="<?= e(setting('site_title')) ?>"></label><label>Телефон<input name="phone" value="<?= e(setting('phone')) ?>"></label><label>Электронная почта<input name="email" value="<?= e(setting('email')) ?>"></label><label>Адрес<input name="address" value="<?= e(setting('address')) ?>"></label><label class="span-2">Краткое описание<textarea name="site_tagline" rows="3"><?= e(setting('site_tagline')) ?></textarea></label></div><button class="button">Сохранить настройки сайта</button></form></section><section class="admin-panel"><p class="eyebrow">ENGINEERING / VENTILATION</p><h2>Настройки калькулятора вентиляции</h2><p class="muted">Тарифы и коэффициенты используются только независимым калькулятором вентиляции. Они не изменяют расчёт кондиционирования или другие инструменты.</p><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="save_record" value="1"><div class="form-grid"><?php foreach ($ventilationSettingFields as $field => [$key,$label,$default,$minimum,$maximum]): ?><label><?= e($label) ?><input type="number" name="<?= e($field) ?>" min="<?= e($minimum) ?>" max="<?= e($maximum) ?>" step="any" required value="<?= e(setting($key,(string)$default)) ?>"></label><?php endforeach; ?></div><button class="button">Сохранить тарифы вентиляции</button></form></section><section class="admin-panel"><p class="eyebrow">ENGINEERING / INSTALLATION</p><h2>Тарифы монтажа кондиционеров и VRV / VRF</h2><p class="muted">Эти расценки используются только отдельным калькулятором монтажа. Изменение ставок не влияет на калькулятор вентиляции или холодильную линейку.</p><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="save_record" value="1"><div class="form-grid"><?php foreach ($installationSettingFields as $field => [$key,$label,$default,$minimum,$maximum]): ?><label><?= e($label) ?><input type="number" name="<?= e($field) ?>" min="<?= e($minimum) ?>" max="<?= e($maximum) ?>" step="any" required value="<?= e(setting($key,(string)$default)) ?>"></label><?php endforeach; ?></div><button class="button">Сохранить тарифы монтажа</button></form></section><section class="admin-panel account-panel"><p class="eyebrow">УЧЁТНАЯ ЗАПИСЬ</p><h2>Логин и пароль администратора</h2><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="change_credentials"><div class="form-grid"><label>Новый логин<input name="login" maxlength="120" required value="<?= e($user['login']) ?>"></label><label>Текущий пароль<input name="current_password" type="password" autocomplete="current-password" required></label><label class="span-2">Новый пароль<input name="new_password" type="password" minlength="10" autocomplete="new-password"><small>Оставьте пустым, если меняете только логин. Новый пароль — не менее 10 символов.</small></label></div><button class="button">Обновить данные администратора</button></form></section>
<?php elseif (in_array($tab,['categories','brands','products','news','pages','gallery'],true) && (!empty($_GET['new'])||$edit)): $f=$edit?:[]; ?><section class="admin-panel edit-panel"><div class="panel-heading"><h2><?= $edit?'Редактировать':'Создать' ?> запись</h2><a href="<?= e(site_path('admin/?tab='.$tab)) ?>">Закрыть ×</a></div><form method="post" enctype="multipart/form-data"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="save_record" value="1"><input type="hidden" name="id" value="<?= (int)($f['id']??0) ?>">
<?php if ($tab==='categories'): ?><div class="form-grid"><label>Название<input name="title" required value="<?= e($f['title']??'') ?>"></label><label>Код / адрес<input name="code" value="<?= e($f['code']??'') ?>" placeholder="создастся автоматически"></label><label>Родительская категория<select name="parent_code"><option value="">Верхний уровень</option><?php foreach (db()->query('SELECT id,code,title FROM categories ORDER BY title') as $c): if ((int)$c['id']===(int)($f['id']??0)) continue; ?><option value="<?= e($c['code']) ?>" <?= (int)($f['parent_id']??0)===(int)$c['id']?'selected':'' ?>><?= e($c['title']) ?></option><?php endforeach; ?></select></label><label>Порядок<input type="number" name="sort_order" value="<?= e($f['sort_order']??100) ?>"></label><label class="span-2">Изображение<input type="file" name="image" accept="image/jpeg,image/png,image/webp"><input class="secondary-input" name="image_url" value="<?= e($f['image_url']??'') ?>" placeholder="или URL изображения"></label></div><label class="check-label"><input type="checkbox" name="active" <?= !isset($f['active'])||$f['active']?'checked':'' ?>> Показывать</label>
<?php elseif ($tab==='brands'): ?><div class="form-grid"><label>Название<input name="name" required value="<?= e($f['name']??'') ?>"></label><label>Логотип<input type="file" name="image" accept="image/jpeg,image/png,image/webp"><input class="secondary-input" name="logo_url" value="<?= e($f['logo_url']??'') ?>" placeholder="или URL логотипа"></label><label class="span-2">Описание<textarea name="description"><?= e($f['description']??'') ?></textarea></label></div><label class="check-label"><input type="checkbox" name="active" <?= !isset($f['active'])||$f['active']?'checked':'' ?>> Активный бренд</label>
<?php elseif ($tab==='products'): ?><div class="form-grid"><label>Модель<input name="model" required value="<?= e($f['model']??'') ?>"></label><label>Артикул<input name="sku" value="<?= e($f['sku']??'') ?>"></label><label>Бренд<select name="brand_id"><option value="">Не выбран</option><?php foreach (db()->query('SELECT id,name FROM brands ORDER BY name') as $b): ?><option value="<?= (int)$b['id'] ?>" <?= (int)($f['brand_id']??0)===(int)$b['id']?'selected':'' ?>><?= e($b['name']) ?></option><?php endforeach; ?></select></label><label>Категория<select name="category_id"><option value="">Не выбрана</option><?php foreach (db()->query('SELECT id,title FROM categories ORDER BY title') as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)($f['category_id']??0)===(int)$c['id']?'selected':'' ?>><?= e($c['title']) ?></option><?php endforeach; ?></select></label><label>Цена, ₽<input type="number" name="price" min="0" step="0.01" value="<?= e($f['price']??0) ?>"></label><label>Фото<input type="file" name="image" accept="image/jpeg,image/png,image/webp"><input class="secondary-input" name="image_url" value="<?= e($f['image_url']??'') ?>" placeholder="или внешний URL"></label><label class="span-2">Описание<textarea name="description" rows="4"><?= e($f['description']??'') ?></textarea></label><label class="span-2">Характеристики (JSON)<textarea name="specifications" rows="4"><?= e($f['specifications']??'[]') ?></textarea></label></div><label class="check-label"><input type="checkbox" name="is_demo" <?= !empty($f['is_demo'])?'checked':'' ?>> Демонстрационный товар</label><label class="check-label"><input type="checkbox" name="active" <?= !isset($f['active'])||$f['active']?'checked':'' ?>> Показывать на сайте</label>
<?php elseif ($tab==='news'||$tab==='pages'): ?><div class="form-grid"><label class="span-2">Заголовок<input name="title" required value="<?= e($f['title']??'') ?>"></label><label>Адрес страницы<input name="slug" value="<?= e($f['slug']??'') ?>" placeholder="создастся автоматически"></label><?php if ($tab==='news'): ?><label>Обложка<input type="file" name="image" accept="image/jpeg,image/png,image/webp"><input class="secondary-input" name="image_url" value="<?= e($f['image_url']??'') ?>" placeholder="или URL обложки"></label><label class="span-2">Анонс<textarea name="excerpt" rows="3"><?= e($f['excerpt']??'') ?></textarea></label><?php endif; ?><label class="span-2">Содержание (разрешена базовая HTML-разметка)<textarea class="content-editor" name="content" rows="15"><?= e($f['content']??'') ?></textarea><small>Заголовки, абзацы, списки, ссылки и таблицы. Скрипты и HTML-атрибуты удаляются при сохранении.</small></label></div><label class="check-label"><input type="checkbox" name="published" <?= !isset($f['published'])||$f['published']?'checked':'' ?>> Опубликовать</label>
<?php else: ?><div class="form-grid"><label class="span-2">Название работы<input name="title" required value="<?= e($f['title']??'') ?>"></label><label>Локация<input name="location" value="<?= e($f['location']??'') ?>"></label><label>Порядок<input type="number" name="sort_order" value="<?= e($f['sort_order']??100) ?>"></label><label class="span-2">Фотография<input type="file" name="image" accept="image/jpeg,image/png,image/webp"><input class="secondary-input" name="image_url" value="<?= e($f['image_url']??'') ?>" placeholder="или URL фото"></label><label class="span-2">Alt-текст<input name="alt_text" value="<?= e($f['alt_text']??'') ?>"></label></div><label class="check-label"><input type="checkbox" name="published" <?= !isset($f['published'])||$f['published']?'checked':'' ?>> Показывать на сайте</label><?php endif; ?><div class="form-actions"><button class="button">Сохранить</button><a class="button button-ghost" href="<?= e(site_path('admin/?tab='.$tab)) ?>">Отмена</a></div></form></section>
<?php elseif ($tab==='categories'): $rows=db()->query('SELECT c.*,p.title parent_title FROM categories c LEFT JOIN categories p ON p.id=c.parent_id ORDER BY c.sort_order,c.title')->fetchAll(); ?><div class="admin-panel table-panel"><table><thead><tr><th>Категория</th><th>Родитель</th><th>Код</th><th>Статус</th><th></th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= e($r['title']) ?></td><td><?= e($r['parent_title']??'Верхний уровень') ?></td><td><?= e($r['code']) ?></td><td><?= $r['active']?'Активна':'Скрыта' ?></td><td><a href="<?= e(site_path('admin/?tab=categories&edit='.$r['id'])) ?>">Изменить</a><?php admin_delete_control((int)$r['id']); ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php elseif ($tab==='brands'): $rows=db()->query('SELECT * FROM brands ORDER BY name')->fetchAll(); ?><div class="admin-panel table-panel"><table><thead><tr><th>Бренд</th><th>Описание</th><th></th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= e($r['description']) ?></td><td><a href="<?= e(site_path('admin/?tab=brands&edit='.$r['id'])) ?>">Изменить</a><?php admin_delete_control((int)$r['id']); ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php elseif ($tab==='products'): $rows=db()->query('SELECT p.*,b.name brand_name,c.title category_title FROM products p LEFT JOIN brands b ON b.id=p.brand_id LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC LIMIT 500')->fetchAll(); ?><div class="admin-panel table-panel"><table><thead><tr><th>Товар</th><th>Бренд / категория</th><th>Цена</th><th></th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= e($r['model']) ?><?= $r['is_demo']?'<small class="demo-label"> · ДЕМО</small>':'' ?><small><?= e($r['sku']) ?></small></td><td><?= e($r['brand_name']??'—') ?><small><?= e($r['category_title']??'—') ?></small></td><td><?= number_format((float)$r['price'],0,',',' ') ?> ₽</td><td><a href="<?= e(site_path('admin/?tab=products&edit='.$r['id'])) ?>">Изменить</a><?php admin_delete_control((int)$r['id']); ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php elseif ($tab==='news'||$tab==='pages'): $table=$tab==='news'?'news':'pages'; $rows=db()->query('SELECT * FROM '.$table.' ORDER BY id DESC')->fetchAll(); ?><div class="admin-panel table-panel"><table><thead><tr><th>Материал</th><th>Адрес</th><th>Статус</th><th></th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= e($r['title']) ?><small><?= e($r['excerpt']??'') ?></small></td><td><?= e($r['slug']) ?></td><td><?= $r['published']?'Опубликован':'Черновик' ?></td><td><a href="<?= e(site_path('admin/?tab='.$tab.'&edit='.$r['id'])) ?>">Изменить</a><?php admin_delete_control((int)$r['id']); ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php elseif ($tab==='gallery'): $rows=db()->query('SELECT * FROM gallery ORDER BY sort_order,id DESC')->fetchAll(); ?><div class="admin-panel table-panel"><table><thead><tr><th>Работа</th><th>Место</th><th>Статус</th><th></th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= e($r['title']) ?></td><td><?= e($r['location']) ?></td><td><?= $r['published']?'Опубликована':'Скрыта' ?></td><td><a href="<?= e(site_path('admin/?tab=gallery&edit='.$r['id'])) ?>">Изменить</a><?php admin_delete_control((int)$r['id']); ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php elseif ($tab==='leads'): $rows=db()->query('SELECT * FROM leads ORDER BY created_at DESC LIMIT 500')->fetchAll(); ?><div class="admin-panel table-panel"><table><thead><tr><th>Имя и дата</th><th>Контакты</th><th>Сообщение</th><th>Статус</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= e($r['name']) ?><small><?= e($r['created_at']) ?></small></td><td><?= e($r['phone']) ?><small><?= e($r['email']) ?></small></td><td><?= e($r['message']) ?></td><td><form method="post" class="inline-status"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="save_record" value="1"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><select name="status"><option value="new" <?= $r['status']==='new'?'selected':'' ?>>Новая</option><option value="in_progress" <?= $r['status']==='in_progress'?'selected':'' ?>>В работе</option><option value="done" <?= $r['status']==='done'?'selected':'' ?>>Завершена</option></select><button class="mini-button">OK</button></form></td></tr><?php endforeach; ?></tbody></table></div>
<?php elseif ($tab==='formulas'): ?><div class="formula-list"><?php foreach(db()->query('SELECT * FROM formulas ORDER BY module,title') as $r): ?><details class="admin-panel formula-item"><summary><?= e($r['title']) ?> <small><?= e($r['module']) ?></small></summary><p class="code-cell"><?= e($r['expression']) ?></p></details><?php endforeach; ?></div><div class="notice">Это исходные расчётные формулы из пакета. Публичный предварительный калькулятор упрощён и служит только для ориентировочной оценки.</div>
<?php elseif ($tab==='anvil_source'):
$sourceTable = (string)($_GET['source_table'] ?? 'catalog_categories');
if (!in_array($sourceTable, KLIMA_ANVIL_EXPORT_TABLES, true)) $sourceTable = 'catalog_categories';
$sourceSearch = trim((string)($_GET['q'] ?? ''));
$sourcePage = max(1, (int)($_GET['page'] ?? 1));
$sourcePageSize = 50;
$sourceWhere = 'source_table=?';
$sourceParams = [$sourceTable];
if ($sourceSearch !== '') {
    $sourceWhere .= ' AND (source_id LIKE ? OR record_json LIKE ?)';
    $sourceParams[] = '%' . $sourceSearch . '%';
    $sourceParams[] = '%' . $sourceSearch . '%';
}
$sourceCountQuery = db()->prepare('SELECT COUNT(*) FROM anvil_export_rows WHERE ' . $sourceWhere);
$sourceCountQuery->execute($sourceParams);
$sourceTotal = (int)$sourceCountQuery->fetchColumn();
$sourcePageCount = max(1, (int)ceil($sourceTotal / $sourcePageSize));
$sourcePage = min($sourcePage, $sourcePageCount);
$sourceOffset = ($sourcePage - 1) * $sourcePageSize;
$sourceRowsQuery = db()->prepare('SELECT source_id,record_json FROM anvil_export_rows WHERE ' . $sourceWhere . ' ORDER BY source_id LIMIT ' . $sourcePageSize . ' OFFSET ' . $sourceOffset);
$sourceRowsQuery->execute($sourceParams);
$sourceRows = $sourceRowsQuery->fetchAll();
$sourceQueryTail = '&source_table=' . rawurlencode($sourceTable) . '&q=' . rawurlencode($sourceSearch);
?>
<section class="admin-panel source-data-tools">
  <p class="eyebrow">ЗЕРКАЛО ДАННЫХ ИЗ ANVIL</p>
  <p class="muted">Исходные записи всех перенесённых таблиц. Каталог, формулы, страницы, галерея и Engineering OS дополнительно доступны в своих обычных разделах. После редактирования JSON нажмите «Применить зеркало к сайту», чтобы обновить эти разделы без повторной загрузки исходного файла.</p>
  <form method="post" class="source-sync-form">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="sync_anvil_mirror">
    <button class="button button-small">Применить зеркало к сайту</button>
    <small class="muted">Все изменения зеркала перезапишут соответствующие сопоставленные поля PHP-сайта.</small>
  </form>
  <form method="get" class="source-data-filter">
    <input type="hidden" name="tab" value="anvil_source">
    <label>Таблица<select name="source_table"><?php foreach (KLIMA_ANVIL_EXPORT_TABLES as $tableName): ?><option value="<?= e($tableName) ?>" <?= $sourceTable === $tableName ? 'selected' : '' ?>><?= e($tableName) ?></option><?php endforeach; ?></select></label>
    <label>Поиск по ID и JSON<input name="q" value="<?= e($sourceSearch) ?>" maxlength="190" placeholder="ID, название или значение"></label>
    <button class="button button-small">Найти</button>
  </form>
  <p class="muted small">Таблица <strong><?= e($sourceTable) ?></strong> · записей: <?= $sourceTotal ?> · страница <?= $sourcePage ?> из <?= $sourcePageCount ?> · по 50 строк.</p>
</section>
<?php if (!$sourceRows): ?><div class="empty-state">В этой таблице пока нет импортированных записей. Сначала выполните перенос из раздела «Резервные копии» Anvil.</div><?php endif; ?>
<div class="source-record-list">
<?php foreach ($sourceRows as $sourceRow):
    $sourceRecord = json_decode((string)$sourceRow['record_json'], false, 512, JSON_THROW_ON_ERROR);
    $sourceJson = json_encode($sourceRecord, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
?>
  <details class="admin-panel source-record">
    <summary><strong><?= e($sourceRow['source_id']) ?></strong><small>Открыть поля</small></summary>
    <form method="post" class="source-record-form">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="save_anvil_export_row" value="1">
      <input type="hidden" name="source_table" value="<?= e($sourceTable) ?>">
      <input type="hidden" name="source_id" value="<?= e($sourceRow['source_id']) ?>">
      <input type="hidden" name="page" value="<?= $sourcePage ?>">
      <label>Запись JSON<textarea class="source-json-editor" name="record_json" rows="18" spellcheck="false" required><?= e($sourceJson) ?></textarea><small>Оставьте поле id без изменений. JSON-поля и ссылки проверяются перед сохранением; парольные и API-секреты запрещены.</small></label>
      <button class="button button-small">Сохранить запись</button>
    </form>
  </details>
<?php endforeach; ?>
</div>
<?php if ($sourcePageCount > 1): ?><nav class="pagination-actions" aria-label="Страницы данных Anvil">
  <?php if ($sourcePage > 1): ?><a class="button button-small button-ghost" href="<?= e(site_path('admin/?tab=anvil_source' . $sourceQueryTail . '&page=' . ($sourcePage - 1))) ?>">← Назад</a><?php endif; ?>
  <span class="muted">Страница <?= $sourcePage ?> / <?= $sourcePageCount ?></span>
  <?php if ($sourcePage < $sourcePageCount): ?><a class="button button-small button-ghost" href="<?= e(site_path('admin/?tab=anvil_source' . $sourceQueryTail . '&page=' . ($sourcePage + 1))) ?>">Далее →</a><?php endif; ?>
</nav><?php endif; ?>
<?php endif; ?></main></div><script src="<?= e(site_path('assets/app.js')) ?>" defer></script></body></html>
